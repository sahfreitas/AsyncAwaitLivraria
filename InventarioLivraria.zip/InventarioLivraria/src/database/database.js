[
    {
      "titulo": "igot",
      "autor": "igot",
      "paginas": "500",
      "editora": "Arqueiro",
      "isbn": "6255515"
    },
    {
      "titulo": "igor",
      "autor": "igot",
      "paginas": "700",
      "editora": "DarkSide Books",
      "isbn": "6255588"
    }
  ]